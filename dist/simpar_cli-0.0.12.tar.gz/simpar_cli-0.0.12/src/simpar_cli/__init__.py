from simpar_cli.simpar import Simpar


def main(im, ii):
	
	simpar = Simpar(im, ii)
	simpar.simpar()